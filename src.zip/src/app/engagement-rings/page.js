import { Footer } from "../_componentStatic/Footer";
import Header from "../_componentStatic/Header";

const EngagementRings = () => {
  return (
    <>

    <div className='container'>
      <h1>Start with a engagement</h1>
    </div>
    

    </>
   
   
  );
};

export default EngagementRings;
