import { Footer } from "../_componentStatic/Footer";
import Header from "../_componentStatic/Header";

const EngagementRings = () => {
  return (
    <>
<Header/>
    <div className='container'>
      <h1>Start with a engagement</h1>
    </div>
      <Footer/>

    </>
   
   
  );
};

export default EngagementRings;
