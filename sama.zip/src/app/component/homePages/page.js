import { ShopDiamondShape } from "./ShopDiamondShape";

export default async function HomePage() {
  const response = await fetch('https://api.rocksama.com/api/v1/diamondshape');
  
  if (!response.ok) {
    console.error('Failed to fetch data');
    return <div>Error fetching banners</div>;
  }

  const shapeData = await response.json();

 
  // const response_1 = await fetch('https://api.rocksama.com/api/v1/product-style');
  
  // if (!response_1.ok) {
  //   console.error('Failed to fetch data');
  //   return <div>Error fetching banners</div>;
  // }

  // const shopStyle = await response_1.json();


  // const response_2 = await fetch('https://api.rocksama.com/api/v1/banners');
  
  // if (!response_2.ok) {
  //   console.error('Failed to fetch data');
  //   return <div>Error fetching banners</div>;
  // }

  // const homeContext = await response_2.json();



  // const response_3 = await fetch('https://api.rocksama.com/api/v1/homecontent');
  
  // if (!response_3.ok) {
  //   console.error('Failed to fetch data');
  //   return <div>Error fetching banners</div>;
  // }

  // const homeAllSections = await response_3.json();



  // // ============see products and wedding collection api start
  // const response_4 = await fetch('https://api.rocksama.com/api/v1/Trellis Rings');
  
  // if (!response_4.ok) {
  //   console.error('Failed to fetch data');
  //   return <div>Error fetching banners</div>;
  // }

  // const anniversaryRings = await response_4.json();
 
  // const response_5 = await fetch('https://api.rocksama.com/api/v1/Vintage Rings');
  
  // if (!response_5.ok) {
  //   console.error('Failed to fetch data');
  //   return <div>Error fetching banners</div>;
  // }

  // const diamondPendants = await response_5.json();
  
  
  // const response_6 = await fetch('https://api.rocksama.com/api/v1/Eternity Rings');
  
  // if (!response_6.ok) {
  //   console.error('Failed to fetch data');
  //   return <div>Error fetching banners</div>;
  // }

  // const tennisBracelets = await response_6.json();


  // const response_7 = await fetch('https://api.rocksama.com/api/v1/Nature Inspired Rings');
  
  // if (!response_7.ok) {
  //   console.error('Failed to fetch data');
  //   return <div>Error fetching banners</div>;
  // }

  // const diamondStuds = await response_7.json();
 
 


  
  // useMemo(() => {
  //   axios
  //     .get(`https://api.rocksama.com/api/v1/widget/Natural diamonds`)
  //     .then((res) => {
  //       setEngagementRings(res.data.data);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // }, []);

  // useMemo(() => {
  //   axios
  //     .get(`https://api.rocksama.com/api/v1/widget/Gemstones`)
  //     .then((res) => {
  //       setWeddingJewelry(res.data.data);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // }, []);

  // useMemo(() => {
  //   axios
  //     .get(`https://api.rocksama.com/api/v1/widget/Lab Grown Diamonds`)
  //     .then((res) => {
  //       setWeddingCollection(res.data.data);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // }, []);



  // const[siteInfo,setSiteInfo]= useState()
  // useMemo(() => {
  //   axios
  //     .get(`https://api.rocksama.com/api/v1/siteinfo`)
  //     .then((res) => {
  //       setSiteInfo(res.data.data);
  //     })
  //     .catch(() => {
  //       console.log("profile API is not working");
  //     });
  // }, []);

  // console.log(homeAllSections);
  
  return (
    <>
      <div className="home-page">
        {/* <Banner homeContext={homeContext}/> */}
        <ShopDiamondShape shapeData={shapeData} />
        {/* <SeeProducts anniversaryRings={anniversaryRings} diamondPendants={diamondPendants} tennisBracelets={tennisBracelets} diamondStuds={diamondStuds}/>
        <ShopDiamondCotegory shopStyle={shopStyle}/>
        <BridalJewellery home={homeAllSections}/>
        <AnniversaryRings home={homeAllSections}/>
        <CelebarteLove home={homeAllSections}/>
        <WeddingCollection engagementRings={engagementRings} weddingJewelry={weddingJewelry} weddingCollection={weddingCollection}/>

        <EngagementBridal home={homeAllSections}/>

        <LoveBrilliance home={homeAllSections}/>
        
        <AnniversaryRingFeatured home={homeAllSections}/> */}
      </div>
    </>
  );
};

